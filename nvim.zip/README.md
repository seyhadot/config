### Neovim editor configuration
